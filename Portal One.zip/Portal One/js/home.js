$(document).ready(function(e){
	$('#the-slider').bxSlider({
		moveSlides:  	1,
		slideWidth: 	1920,
		controls:       false,
		adaptiveHeight: false,
		auto:			true,
		pause: 			8000
	});
});